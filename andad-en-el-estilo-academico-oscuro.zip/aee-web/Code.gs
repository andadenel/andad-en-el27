/** Código vinculado a la hoja «AEE — Registro de contactos». */
const SHEET_NAME = 'Solicitudes';
const HEADERS = ['Fecha y hora','Nombre','Correo','Interés','Mensaje','Estado','ID'];
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
  sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
  sheet.setFrozenRows(1);
  sheet.getRange('A:A').setNumberFormat('yyyy-mm-dd hh:mm');
}
function doPost(e) {
  let ok = false;
  let id = '';
  try {
    const p = (e && e.parameter) || {};
    id = String(p.request_id || '').slice(0, 100);
    if (p.website) throw Error('spam');
    const name = String(p.name || '').trim();
    const email = String(p.email || '').trim();
    const interest = String(p.interest || '').trim();
    const message = String(p.message || '').trim();
    if (!name || name.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 200 || !message || message.length > 3000 || !['Misiones','Voluntariado','Publicaciones','Estudios bíblicos','Otra consulta'].includes(interest) || !id) throw Error('invalid');
    const lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
      if (!sheet) throw Error('Ejecuta setup primero');
      const last = sheet.getLastRow();
      if (last > 1 && sheet.getRange(2,7,last-1,1).getValues().some(row => row[0] === id)) {
        ok = true; // No duplicar si el usuario reintenta.
      } else {
        // Impide que texto introducido por visitantes se interprete como fórmula.
        const safe = s => /^[=+\-@]/.test(s) ? "'" + s : s;
        sheet.appendRow([new Date(), safe(name), safe(email), safe(interest), safe(message), 'Pendiente', id]);
        ok = true;
      }
    } finally { lock.releaseLock(); }
  } catch (err) { console.error(err); }
  const payload = JSON.stringify({type:'AEE_CONTACT_RESULT', ok:ok, id:id}).replace(/</g,'\\u003c');
  return HtmlService.createHtmlOutput('<!doctype html><html><body><script>parent.postMessage('+payload+', "*");<\/script></body></html>');
}
